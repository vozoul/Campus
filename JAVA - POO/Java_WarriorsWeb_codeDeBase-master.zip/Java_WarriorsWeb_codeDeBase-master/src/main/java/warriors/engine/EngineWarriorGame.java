package warriors.engine;

import warriors.model.GameWarriors;

public class EngineWarriorGame {

    // HERE TO IMPLEMENT GAME !!!
    public GameWarriors launchGame(GameWarriors gameReceived) {
        return gameReceived;
    }
}
