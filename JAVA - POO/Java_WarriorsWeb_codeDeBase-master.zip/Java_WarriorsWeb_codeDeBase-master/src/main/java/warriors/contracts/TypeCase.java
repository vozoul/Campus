package warriors.contracts;

public enum TypeCase {
    ENNEMY,
    NONE,
    ARME,
    MAGIE,
    POTION  
}
