package warriors.contracts;

public enum TypeHero {
    MAGICIEN,
    GUERRIER
}
