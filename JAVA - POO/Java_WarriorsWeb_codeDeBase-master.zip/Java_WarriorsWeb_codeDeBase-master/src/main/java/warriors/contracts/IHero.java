package warriors.contracts;

public interface IHero {

    String getName();

    String getImage();

    int getLife();

    int getAttackLevel();
}
