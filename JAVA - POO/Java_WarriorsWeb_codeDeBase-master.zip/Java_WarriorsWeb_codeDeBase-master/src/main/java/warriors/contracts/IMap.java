package warriors.contracts;

import java.util.ArrayList;
import warriors.model.Case;

public interface IMap {

    public String getName();

    public ArrayList<Case> getCases();
}
