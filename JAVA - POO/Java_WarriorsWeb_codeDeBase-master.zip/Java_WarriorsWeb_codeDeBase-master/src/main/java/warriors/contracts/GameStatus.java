package warriors.contracts;

public enum GameStatus {
    IN_PROGRESS,
    GAME_OVER,
    FINISHED
}
