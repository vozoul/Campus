package warriors.model;

public class Case {
}
