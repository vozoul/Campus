package warriors.model;

public class GameState {
}
