import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Game } from './app/model/game';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  API_URL = 'http://localhost:8080/Donjons-it8/api';

  constructor(private httpClient: HttpClient) { }


  public getGame(): Observable<any> {
    const api = this.API_URL + '/game';
    return this.httpClient.get(api).pipe(
      map(this.extractData));
  }

  public nextTurn(json: Game): Observable<any> {
    const api = this.API_URL + '/game';
    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    const dataT = 'game=' + JSON.stringify(json);
    return this.httpClient.post(api, dataT, { headers }).pipe(
      map(this.extractData));
  }

  private extractData(res: Response) {
    const body = res;
    return body || {};
  }





}
