import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BoardComponent } from './board/board.component';
import { GameComponent } from './game/game.component';

const routes: Routes = [
  { path: 'board', component: BoardComponent },
  { path: 'game', component: GameComponent },
  { path: '**', redirectTo: '/board' } // to redirect all path unknown
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
