import { Component, OnInit, Input } from '@angular/core';
import { Hero } from '../model/hero';

@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css'],
})
export class HeroComponent implements OnInit {

  imageGuerrier: string;
  numbersLife: number[];
  numbersPower: number[];

  private hero: Hero;
  @Input()
  set iHero(hero: Hero) {
    if (hero) {
      this.hero = hero;
      this.fillHero();
    }

  }
  get iHero(): Hero {
    return this.hero;
  }

  constructor() { }

  ngOnInit() {
  }

  fillHero() {
    this.imageGuerrier = 'assets/' + this.hero.image + '.png';
    this.numbersLife = Array(this.hero.life).fill(4);
    this.numbersPower = Array(this.hero.attackLevel).fill(4);
  }
}
