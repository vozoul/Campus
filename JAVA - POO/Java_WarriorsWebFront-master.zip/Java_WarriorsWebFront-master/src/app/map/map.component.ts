import { Component, OnInit, Input, Output } from '@angular/core';
import { GameState } from '../model/gameState';
import { Map } from '../model/map';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  resumeMessage: string;

  private mapGame: Map;
  @Input()
  set iMap(mapGame: Map) {
    if (mapGame) {
      console.table(mapGame)
      this.mapGame = mapGame;
    }
  }
  get iMap(): Map {
    return this.mapGame;
  }

  private state: GameState;
  @Input()
  set iState(state: GameState) {
    if (state) {
      this.state = state;
      this.isEnd(state);
    }
  }
  get iState(): GameState {
    return this.state;
  }

  @Output()
  oSendFinished: EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }

  isEnd(state: GameState) {
    if (state.status === 'GAME_OVER') {
      this.resumeMessage = 'Vous avez perdu';
    } else if (state.status === 'FINISHED') {
      this.resumeMessage = 'Vous avez gagné !!';
    } else {
      this.resumeMessage = 'Appuyer sur \'Tour suivant\' pour le prochain tour !';
    }
    this.oSendFinished.emit(state.status);
  }
}
