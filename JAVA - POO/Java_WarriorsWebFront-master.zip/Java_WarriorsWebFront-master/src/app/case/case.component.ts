import { Component, OnInit, Input } from '@angular/core';
import { CaseMap } from '../model/case';

@Component({
  selector: 'app-case',
  templateUrl: './case.component.html',
  styleUrls: ['./case.component.css']
})
export class CaseComponent implements OnInit {

  imageCase = 'assets/NONE.png';
  numbersLife: number[];
  numbersPower: number[];

  private caseMap: CaseMap;
  @Input()
  set iCaseMap(caseMap: CaseMap) {
    if (caseMap) {
      this.caseMap = caseMap;
      this.fillCaseMap();
    }
  }
  get iCaseMap(): CaseMap {
    return this.caseMap;
  }

  constructor() { }

  ngOnInit() {
  }

  fillCaseMap() {
    if (this.caseMap.name) {
      this.imageCase = 'assets/' + this.caseMap.name.replace(/ /g, '_') + '.png';
      this.numbersLife = Array(this.caseMap.life).fill(4);
      this.numbersPower = Array(this.caseMap.power).fill(4);
    } else {
      this.imageCase = 'assets/NONE.png';
    }
  }
}
