import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';

import { Game } from '../model/game';
import { Hero } from '../model/hero';
import { Map } from '../model/map';
import { GameState } from '../model/gameState';
import { CaseMap } from '../model/case';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {

  game: Game;
  hero: Hero;
  map: Map;
  gameState: GameState;
  caseHero: CaseMap;
  isDisplayNext = true;

  constructor(private apiService: ApiService) { }

  ngOnInit() {
    if (!this.isGameInProgress()) {
      this.getNewGame();
    } else {
      this.game = JSON.parse(localStorage.getItem('game'));
      this.map = this.game.map;
      this.gameState = this.game.gameState;
      this.retrieveHeroOnMap();
    }
  }

  isGameInProgress(): boolean {
    this.game = JSON.parse(localStorage.getItem('game'));
    if (this.game) {
      this.hero = this.game.hero;
    }
    if (this.game) {
      return true;
    } else {
      return false;
    }
  }

  getNewGame() {
    this.apiService.getGame().subscribe(response => {
      localStorage.setItem('game', JSON.stringify(response));
      this.game = response;
      this.hero = this.game.hero;
      this.map = this.game.map;
      this.gameState = this.game.gameState;
      this.retrieveHeroOnMap();

    });
  }

  nextTurn() {
    let gameJson: Game;
    if (this.isGameInProgress()) {
      gameJson = JSON.parse(localStorage.getItem('game'));
    } else {
      this.isDisplayNext = true;
      this.getNewGame();
      gameJson = this.game;
    }
    this.apiService.nextTurn(this.game).subscribe(response => {
      localStorage.setItem('game', JSON.stringify(response));
      this.game = response;
      this.hero = response.hero;
      this.map = this.game.map;
      this.gameState = this.game.gameState;
      this.retrieveHeroOnMap();
    });
  }

  retrieveHeroOnMap() {
    this.map.cases.forEach(caseMap => {
      if (caseMap.isHeroHere) {
        this.caseHero = caseMap;
      }
    });
  }

  initGame() {
    localStorage.removeItem('game');
    this.getNewGame();
  }

  onDisplayButton(event) {
    this.isDisplayNext = !(event === 'FINISHED' || event === 'GAME_OVER');
  }
}
