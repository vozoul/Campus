import { CaseMap } from './case';

export class Map {
    name: string;
    size: number;
    cases: CaseMap[];
}