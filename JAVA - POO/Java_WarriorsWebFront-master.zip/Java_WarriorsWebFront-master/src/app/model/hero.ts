export class Hero {
    name: string;
    life: number;
    attackLevel: number;
    maxLife: number;
    maxAttackLevel: number;
    image: string;
    type: string;
}
