export class GameState {
    status: string;
    dice: number;
}