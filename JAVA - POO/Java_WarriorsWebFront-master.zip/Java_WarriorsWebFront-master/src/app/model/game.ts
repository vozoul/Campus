import { Hero } from './hero';
import { Map } from './map';
import { GameState } from './gameState';

export class Game {
    map: Map;
    hero: Hero;
    gameState: GameState;
}
