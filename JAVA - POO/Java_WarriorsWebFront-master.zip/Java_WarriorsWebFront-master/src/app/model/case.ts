export class CaseMap {
    name: string;
    life: number;
    power: number;
    type: string;
    position: number;
    isHeroHere: boolean;
}