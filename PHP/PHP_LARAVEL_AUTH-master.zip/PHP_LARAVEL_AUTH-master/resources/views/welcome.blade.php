@extends('layout')

@section('content')

    <a href="{{ route('article.index') }}">Rendez vous sur la page article pour la suite du projet</a>
@endsection
